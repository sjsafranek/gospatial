
## What could be next steps for OSM Buildings

- one more roof shape
- roof color by building type
- handle render modes as plugins
- new adapters, i.e. for ArcGIS, Google Maps, Here
