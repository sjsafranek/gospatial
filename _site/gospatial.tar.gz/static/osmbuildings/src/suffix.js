
  global.OSMBuildings = osmb;

}(this));
